package com.example.finalprojecttagen

data class Pet(
    val id: Int? = null,
    val name: String,
    val url: String,
    val desc: String
)
